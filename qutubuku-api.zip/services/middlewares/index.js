const jwtStrategy = require('./jwtStrategy')

module.exports = {
    jwtStrategy
}