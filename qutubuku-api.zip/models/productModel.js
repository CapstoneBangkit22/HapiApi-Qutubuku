const {validator} = require('../types')
const dayjs = require('dayjs')
const types = {
    sku: "",
    name: "",
    description: "",
    stock: 0,
    photo: "http://localhost:7897/images/placeholder.png",
    stock_hold: 0,
    total_stock: 0,
    price: 0,
    unit: "pcs",
    category: null
}

class CollectionProduct {

    constructor({sku, name, description, photo, stock, stock_hold, total_stock, price, unit, category} = types) {
        this.sku = validator.string(sku)
        this.name = validator.string(name)
        this.description = validator.string(description)
        this.photo = photo ? validator.string(photo) : "http://localhost:7897/images/placeholder.png"
        this.stock = validator.number(parseFloat(stock))
        this.stock_hold = validator.number(parseFloat(stock_hold || 0))
        this.total_stock = total_stock ? validator.number(parseFloat(total_stock)) : this.stock
        this.price = validator.number(parseFloat(price))
        this.unit = unit ? validator.string(unit) : "pcs"
        this.category = category || null
        this.created_date = dayjs().format('YYYY-MM-DD HH:mm:ss')
        this.last_updated = dayjs().format('YYYY-MM-DD HH:mm:ss')
    }

    toObject = () => {
        return {
            sku: this.sku,
            name: this.name,
            description: this.description,
            photo: this.photo,
            stock: this.stock,
            stock_hold: this.stock_hold,
            total_stock: this.total_stock,
            price: this.price,
            unit: this.unit,
            category: this.category,
            created_date: this.created_date,
            last_update: this.last_updated
        }
    }
}

module.exports = CollectionProduct