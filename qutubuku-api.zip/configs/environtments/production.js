module.exports = {
    JWT_SECRET_KEY: process.env.JWT_SECRET_KEY,
    HOST: process.env.HOST,
    PORT: process.env.PORT,
}