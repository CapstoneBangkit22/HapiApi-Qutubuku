module.exports = {
    JWT_SECRET_KEY: 'bismillahirrohmanirrohim',
    HOST: 'localhost',
    PORT: 7897,
}