const firebaseCredential = require('./firebaseCredential.json')

module.exports = {
    firebaseCredential
}