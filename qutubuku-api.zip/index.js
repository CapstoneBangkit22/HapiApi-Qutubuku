const { server } = require("./services");

// Start services
server()