const userRoutes = require('./userRoutes')
const productRoutes = require('./productRoutes')
const cartRoutes = require('./cartRoutes')
const invoiceRoutes = require('./invoiceRoutes')
const otherRoutes = require('./otherRoutes')

const routes = [
    ...userRoutes,
    ...productRoutes,
    ...cartRoutes,
    ...invoiceRoutes,
    ...otherRoutes
]

module.exports = routes