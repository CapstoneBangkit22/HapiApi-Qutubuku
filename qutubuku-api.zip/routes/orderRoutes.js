const abs_path = '/api/order'
const { FETCH_REQUEST_TYPES } = require("../types")
const { firestoreDB } = require('../services/firebase')
const { CollectionOrder } = require('../models')
const { result } = require("./utils")
const { collection } = require("firebase/firestore")

// CollectionRef

const colRef = collection(firestoreDB, 'orders_collection')

// Handlers

const handlerGetOrders = async (req, res) => {

    const data = []
    const products = await getDocs(colRef)
    products.forEach((item) => data.push({id: item.id, ..._data}))

    return result({res, data, status: 200, total: data.length})
}

const handlerGetOrder = async (req, res) => {

    const {order_id} = req.params
    const docRef = doc(colRef, order_id)
    const order = await getDoc(docRef)
    const data = {id: order.id, ...order.data()}

    return result({res, data})
}

// Routing

const routes = [
    {
        method: FETCH_REQUEST_TYPES.GET,
        path: abs_path,
        handler: handlerGetOrders
    },
    {
        method: FETCH_REQUEST_TYPES.GET,
        path: abs_path + '/{order_id}',
        handler: handlerGetOrder
    },
]

module.exports = routes